package com.example.whatsappclone;

import java.util.ArrayList;

public class Chat {
    public ArrayList<String> chat;


    public Chat(ArrayList chat) {
        this.chat = chat;

    }
    public ArrayList<String> getChat() {
        return chat;
    }

    public void setChat(ArrayList<String> chat) {
        this.chat = chat;
    }
}
